# 112. React contextType & useContext()

hoc/Aux.js

const aux = props => props.children;

export default aux;
